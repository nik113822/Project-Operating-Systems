# Question 2 — Processes and message queues

The numerical integral

```text
f(x) = ln(x) × sqrt(x), for x ∈ [1, 4]
```

is evaluated with the midpoint rule.

Files:

- `integral_seq.c`: sequential baseline supplied in the assignment.
- `integral_msgq.c`: four child processes calculate separate subranges and send partial results to the parent through a System V message queue.

## Build

```bash
cd question2
make
```

## Run

```bash
./integral_seq
./integral_msgq
```

The expected numerical result is approximately:

```text
4.28245881
```

The submitted report used four processes (`NUM_PROCESSES = 4`). The source file retains that design while making the queue creation, message sizes, child collection and queue cleanup deterministic.
