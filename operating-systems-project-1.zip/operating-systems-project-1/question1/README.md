# Question 1 — Shell scripting

`logparser.sh` is the Bash implementation included in the submitted report. It processes the supplied `access.log` file.

Run all commands from this directory:

```bash
cd question1
chmod +x logparser.sh
```

## Commands used by the submitted implementation

```bash
./logparser.sh
./logparser.sh access.log
./logparser.sh access.log--usrid
./logparser.sh access.log-method
./logparser.sh access.log--servprot
./logparser.sh access.log--browsers
./logparser.sh access.log--datum
```

Several options request their final value interactively, exactly as in the submitted implementation:

- `access.log--usrid` asks for a username.
- `access.log-method` asks for `get` or `post`.
- `access.log--servprot` asks for `IPv4` or `IPv6`.
- `access.log--datum` asks for a month abbreviation from `Jan` to `Dec`.

Expected browser counts for the supplied log:

```text
Mozilla 1057
Chrome 124
Safari 124
Edg 63
```
